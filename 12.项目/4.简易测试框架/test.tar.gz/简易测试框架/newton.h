/*************************************************************************
	> File Name: lighting_god.h
	> Author:TheIslland 
	> Mail: 861436930@qq.com
	> Created Time: 2018年10月07日 星期日 16时37分14秒
 ************************************************************************/

#ifndef _LIGHTING_GOD_H
#define _LIGHTING_GOD_H

double newton (double n);

#endif
