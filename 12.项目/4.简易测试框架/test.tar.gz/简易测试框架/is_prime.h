/*************************************************************************
	> File Name: is_prime.h
	> Author:TheIslland 
	> Mail: 861436930@qq.com
	> Created Time: 2018年10月07日 星期日 11时38分05秒
 ************************************************************************/

#ifndef _IS_PRIME_H
#define _IS_PRIME_H

int is_prime(int);

#endif
