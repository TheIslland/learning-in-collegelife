/*************************************************************************
	> File Name: half_sqrt.h
	> Author:TheIslland 
	> Mail: 861436930@qq.com
	> Created Time: 2018年10月07日 星期日 16时55分14秒
 ************************************************************************/

#ifndef _HALF_SQRT_H
#define _HALF_SQRT_H
    double half_sqrt(double);
#endif
